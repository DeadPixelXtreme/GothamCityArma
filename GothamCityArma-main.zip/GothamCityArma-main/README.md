# GothamCityArma
Gotham City Arma Map
Gotham City land mass with temp land bridges.
Added 2 bridges but they have no floor. You can walk through them? Unsure how to fix.
Need to start building the port (Road, containers, cranes, rubbish, fences etc...
